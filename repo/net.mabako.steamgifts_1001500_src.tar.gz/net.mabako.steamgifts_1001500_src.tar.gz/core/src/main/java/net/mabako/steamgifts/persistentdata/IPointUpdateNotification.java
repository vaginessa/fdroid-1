package net.mabako.steamgifts.persistentdata;

public interface IPointUpdateNotification {
    void onUpdatePoints(int newPoints);
}
