package net.mabako.steamgifts.fragments.interfaces;

import net.mabako.steamgifts.data.User;

public interface IUserNotifications {
    void onUserUpdated(User user);
}