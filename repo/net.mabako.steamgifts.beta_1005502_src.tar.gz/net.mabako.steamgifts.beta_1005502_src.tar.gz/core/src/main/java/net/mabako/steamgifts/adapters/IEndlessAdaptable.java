package net.mabako.steamgifts.adapters;

/**
 * Entry in an endless adapter.
 */
public interface IEndlessAdaptable {
    int getLayout();
}
